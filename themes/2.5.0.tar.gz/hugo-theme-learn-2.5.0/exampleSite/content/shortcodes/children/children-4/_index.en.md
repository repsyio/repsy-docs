+++
title = "page 4"
description = "This is a demo child page"
hidden = true
+++

This is a demo child page, not displayed in the menu