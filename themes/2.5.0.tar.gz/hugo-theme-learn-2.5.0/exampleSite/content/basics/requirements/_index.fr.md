---
title: Prérequis
weight: 10
disableToc: true
---

Grâce à la simplicité d'Hugo, cette page est vide car il n'y a quasi pas de prérequis pour utiliser le thème.

Téléchargez la dernière version du [binaire Hugo (> 0.25)](https://gohugo.io/getting-started/installing/) pour votre Système d'exploitation (Windows, Linux, Mac) : et c'est tout !

![Magic](/en/basics/requirements/images/magic.gif?classes=shadow)
