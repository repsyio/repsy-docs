---
title: Content
weight: 10
chapter: true
pre: "<b>2. </b>"
---

### Chapter 2

# Content

Find out how to create and organize your content quickly and intuitively.
